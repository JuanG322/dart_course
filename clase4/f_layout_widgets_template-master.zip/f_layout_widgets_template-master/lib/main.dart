import 'package:flutter/material.dart';
import 'package:misiontic_todo/ui/app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ToDoApp());
}
