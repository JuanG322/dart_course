import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:misiontic_todo/ui/pages/content_page.dart';

class ToDoApp extends StatelessWidget {
  const ToDoApp({Key? key}) : super(key: key);

  @override
  // COMPLETAR:
  // Debes implementar el metodo build:
  // 1. Crea el metodo build.
  // 2. Crea el MaterialApp
  // Hint: build -> MaterialApp -> ContentPage
}