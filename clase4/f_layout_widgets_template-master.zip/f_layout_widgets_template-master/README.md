# Flutter - Layout Building

![Simulator Screen Recording - iPhone 12 Pro Max - 2022-07-09 at 19 49 43](https://user-images.githubusercontent.com/25647254/178127216-b91fe42f-f858-434d-9f8a-552ec0637c41.gif)

La aplicación de TODO para la sesión 4 terminada.

Video guia para el profesor:

https://www.youtube.com/watch?v=4TiP7de23As

Solucion: https://github.com/MisionTIC4b/f_layout_widgets
