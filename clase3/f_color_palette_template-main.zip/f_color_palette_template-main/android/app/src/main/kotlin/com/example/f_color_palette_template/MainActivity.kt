package com.example.f_color_palette_template

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
