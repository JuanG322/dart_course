# f_color_palette_template

Proyecto con Widgets sin estado con varias paletas de colores tomados de https://colorhunt.co/

<img src="https://user-images.githubusercontent.com/4458129/169327058-302698d4-c710-4278-aa4e-09a8a3320edf.gif" width="300" />

Solución:
https://github.com/MisionTIC4b/f_color_palette
