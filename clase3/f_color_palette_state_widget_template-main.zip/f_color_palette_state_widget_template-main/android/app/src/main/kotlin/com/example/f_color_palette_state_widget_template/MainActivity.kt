package com.example.f_color_palette_state_widget_template

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
