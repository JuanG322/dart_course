# f_color_palette_state_widget_template

Proyecto con Widgets con estado con varias paletas de colores que cambia el Theme de la aplicación

<img src="https://user-images.githubusercontent.com/4458129/169329344-74b1711e-1763-4ded-8456-76abf5b09b56.gif" width="300" />

Solución:
https://github.com/MisionTIC4b/f_color_palette_state_widget
