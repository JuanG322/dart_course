import 'package:dart_basics/converter.dart';

class MainConverter {
  // TODO: Define dos varibles privadas String nulables: [binary] y [decimal]

  MainConverter() {
    // TODO: Inicializa [binary] y [decimal] en ['0'] solo cuando sean nulos
    // TODO-HINT: Null-sound assignment
  }

  // TODO: Crea un [setter] para [binary] con el parametro nulable.

  // TODO: Crea un [setter] para [decimal] con el parametro nulable.

  String convertBinary() {
    // TODO: Asegurate que [binary] no es nulo antes de intentar la conversion.
    // TODO: Usa [Converter] para convertir el numero binario a un numero decimal.
  }

  String convertDecimal() {
    // TODO: Asegurate que [decimal] no es nulo antes de intentar la conversion.
    // TODO: Usa [Converter] para convertir el numero decimal a un numero binario.
  }
}
