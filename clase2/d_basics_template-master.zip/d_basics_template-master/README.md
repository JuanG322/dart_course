# Conversor Binario-Decimal Dart

![Dart Console](https://user-images.githubusercontent.com/25647254/180616708-5cd9a5ef-ec5d-4e68-9b99-bae0cfef5eee.gif)

En este ejemplo se implementa un conversor binario-decimal para ejecución desde consola.

Solución: https://github.com/MisionTIC4b/d_basics_template
