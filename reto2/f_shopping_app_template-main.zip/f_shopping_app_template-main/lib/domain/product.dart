class Product {
  int id;
  String name;
  int price;
  int quantity = 0;

  Product(this.id, this.name, this.price);
}
