package com.example.f_shopping_app_r2_template

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
