import 'package:flutter/material.dart';
import 'ui/my_app.dart';

// punto de entrada de la aplicación
void main() {
  runApp(const MyApp());
}
