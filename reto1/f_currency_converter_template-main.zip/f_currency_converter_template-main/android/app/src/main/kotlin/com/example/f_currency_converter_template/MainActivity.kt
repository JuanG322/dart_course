package com.example.f_currency_converter_template

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
